package com.safeanchor;

import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/** Mini-Baritone: tìm block mục tiêu, dò đường (Dijkstra, đào xuyên khi cần), né lava/lửa/xương rồng/magma, đi và đào. */
public class AutoMine {
    static final Direction[] H = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    static final Set<Block> targets = new HashSet<>();
    static int sig;
    static BlockPos goal;
    static List<BlockPos> path = new ArrayList<>();
    static int scanCd, stuck, pause;
    static BlockPos lastPos;
    static float lastHp;
    static boolean held;

    public static void toggle(MinecraftClient mc) {
        Config.I.mineOn = !Config.I.mineOn; Config.save();
        if (!Config.I.mineOn) stop(mc);
        Util.msg("Tự đào: " + (Config.I.mineOn ? "§aBẬT" : "§cTẮT"));
    }

    static void stop(MinecraftClient mc) {
        if (held) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false; }
        goal = null; path.clear();
    }

    // ---------- kiểm tra block ----------
    static boolean lava(World w, BlockPos p) { FluidState f = w.getFluidState(p); return !f.isEmpty() && f.isIn(FluidTags.LAVA); }
    static boolean danger(World w, BlockPos p) {
        Block b = w.getBlockState(p).getBlock();
        return lava(w, p) || b == Blocks.FIRE || b == Blocks.SOUL_FIRE || b == Blocks.MAGMA_BLOCK || b == Blocks.CACTUS
                || b == Blocks.SWEET_BERRY_BUSH || b == Blocks.COBWEB || b == Blocks.POWDER_SNOW || b == Blocks.CAMPFIRE
                || b == Blocks.SOUL_CAMPFIRE || b == Blocks.WITHER_ROSE || b == Blocks.POINTED_DRIPSTONE;
    }
    static boolean nearLava(World w, BlockPos p) {
        for (Direction d : Direction.values()) if (lava(w, p.offset(d))) return true;
        return false;
    }
    static boolean passable(World w, BlockPos p) {
        var s = w.getBlockState(p);
        return s.getCollisionShape(w, p).isEmpty() && s.getFluidState().isEmpty() && !danger(w, p);
    }
    static boolean floor(World w, BlockPos p) {
        var s = w.getBlockState(p);
        return !s.getCollisionShape(w, p).isEmpty() && s.getFluidState().isEmpty() && !danger(w, p);
    }
    static boolean breakable(World w, BlockPos p) {
        var s = w.getBlockState(p);
        if (s.isAir() || !s.getFluidState().isEmpty() || danger(w, p) || s.hasBlockEntity()) return false;
        if (s.getHardness(w, p) < 0) return false;
        return !nearLava(w, p) && w.getFluidState(p.up()).isEmpty();
    }
    /** chi phí để dọn ô: 0 trống, >0 phải đào, <0 không được */
    static double clearCost(World w, BlockPos p) {
        if (passable(w, p)) return 0;
        if (breakable(w, p)) return 3 + w.getBlockState(p).getHardness(w, p);
        return -1;
    }

    record Node(BlockPos pos, double g, double f) {}

    static List<BlockPos> findPath(World w, BlockPos start, BlockPos target, int limit) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble(Node::f));
        Map<BlockPos, Double> best = new HashMap<>();
        Map<BlockPos, BlockPos> from = new HashMap<>();
        open.add(new Node(start, 0, 0)); best.put(start, 0.0);
        int n = 0;
        while (!open.isEmpty() && n++ < limit) {
            Node cur = open.poll();
            BlockPos cp = cur.pos;
            if (cur.g > best.getOrDefault(cp, 1e18)) continue;
            // đích: block mục tiêu kề chân hoặc đầu
            if (adjacent(cp, target) || adjacent(cp.up(), target)) {
                LinkedList<BlockPos> r = new LinkedList<>();
                for (BlockPos q = cp; q != null && !q.equals(start); q = from.get(q)) r.addFirst(q);
                return r;
            }
            for (Direction d : H) for (int dy = -1; dy <= 1; dy++) {
                BlockPos nf = cp.offset(d).up(dy);
                if (Math.abs(nf.getX() - start.getX()) > 40 || Math.abs(nf.getZ() - start.getZ()) > 40) continue;
                if (!floor(w, nf.down())) continue;
                if (nearLava(w, nf) || nearLava(w, nf.up()) || nearLava(w, nf.down())) continue;
                double cost = 1;
                BlockPos[] cells = dy == 1 ? new BlockPos[]{cp.up(2), nf, nf.up()} : dy == -1 ? new BlockPos[]{nf.up(), nf} : new BlockPos[]{nf, nf.up()};
                boolean ok = true;
                for (BlockPos cell : cells) {
                    if (cell.equals(target)) { cost += 2; continue; }
                    double cc = clearCost(w, cell);
                    if (cc < 0) { ok = false; break; }
                    cost += cc;
                }
                if (!ok) continue;
                double g = cur.g + cost;
                if (g < best.getOrDefault(nf, 1e18)) {
                    best.put(nf, g); from.put(nf, cp);
                    double hh = Math.sqrt(nf.getSquaredDistance(target)) * 1.2;
                    open.add(new Node(nf, g, g + hh));
                }
            }
        }
        return null;
    }
    static boolean adjacent(BlockPos a, BlockPos t) { return a.getManhattanDistance(t) == 1; }

    // ---------- chọn mục tiêu ----------
    static void rebuild() {
        targets.clear();
        for (String s : Config.I.mineList) {
            Identifier i = Identifier.tryParse(s.contains(":") ? s : "minecraft:" + s);
            if (i == null) continue;
            Block b = Registries.BLOCK.get(i);
            if (b != Blocks.AIR) targets.add(b);
        }
    }

    static BlockPos findTarget(MinecraftClient mc) {
        int r = (int) Config.I.mineRange;
        BlockPos pc = mc.player.getBlockPos(), best = null; double bd = 1e18;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            m.set(pc.getX() + dx, pc.getY() + dy, pc.getZ() + dz);
            if (!targets.contains(mc.world.getBlockState(m).getBlock())) continue;
            double d = dx * dx + dy * dy * 1.5 + dz * dz;
            if (d < bd && !nearLava(mc.world, m)) { bd = d; best = m.toImmutable(); }
        }
        return best;
    }

    static boolean pick(ItemStack s) { return s.isIn(ItemTags.PICKAXES); }

    static boolean mine(MinecraftClient mc, BlockPos cell) {
        var p = mc.player;
        Vec3d c = Vec3d.ofCenter(cell);
        if (p.getEyePos().distanceTo(c) > 4.6) return false;
        if (!pick(p.getMainHandStack())) Util.selectItem(AutoMine::pick);
        Util.aim(p, c);
        Vec3d d = c.subtract(p.getEyePos());
        mc.interactionManager.updateBlockBreakingProgress(cell, Direction.getFacing(-d.x, -d.y, -d.z));
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.mineOn || !c.enabled || p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) { if (held) stop(mc); return; }
        if (pause > 0) { pause--; return; }
        // né nguy hiểm: mất máu / máu thấp / đứng cạnh lava thì dừng 3 giây
        if (p.getHealth() < 6 || p.isOnFire() || p.hurtTime > 0 || p.getHealth() < lastHp - 0.5f) {
            lastHp = p.getHealth(); stop(mc); pause = 60; Util.warn("Mất máu/nguy hiểm - Tự đào tạm dừng"); return;
        }
        lastHp = p.getHealth();
        int s = Objects.hash(c.mineList); if (s != sig) { sig = s; rebuild(); goal = null; path.clear(); }
        if (targets.isEmpty()) return;

        if (goal != null && !targets.contains(w.getBlockState(goal).getBlock())) { goal = null; path.clear(); }
        if (goal == null) {
            if (scanCd-- > 0) return;
            scanCd = 30;
            goal = findTarget(mc);
            if (goal == null) { stop(mc); return; }
            var r = findPath(w, p.getBlockPos(), goal, 9000);
            if (r == null) { Util.warn("Không tìm được đường tới block"); goal = null; return; }
            path = new ArrayList<>(r); stuck = 0;
        }

        // chống kẹt
        if (p.getBlockPos().equals(lastPos)) { if (++stuck > 80) { stuck = 0; goal = null; path.clear(); return; } } else { stuck = 0; lastPos = p.getBlockPos(); }

        if (path.isEmpty()) {          // đã kề block mục tiêu -> đào
            mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false;
            mine(mc, goal); return;
        }
        BlockPos next = path.get(0), feet = p.getBlockPos();
        if (feet.equals(next)) { path.remove(0); return; }
        // dọn chướng ngại ở ô kế tiếp
        List<BlockPos> need = new ArrayList<>();
        if (next.getY() > feet.getY()) need.add(feet.up(2));
        need.add(next.up()); need.add(next);
        for (BlockPos cell : need) {
            if (cell.equals(goal)) continue;
            if (!passable(w, cell)) {
                mc.options.forwardKey.setPressed(false); held = false;
                if (!breakable(w, cell) || !mine(mc, cell)) { goal = null; path.clear(); }
                return;
            }
        }
        // đi tới ô kế tiếp
        Vec3d to = Vec3d.ofBottomCenter(next);
        Util.aim(p, new Vec3d(to.x, p.getEyeY(), to.z));
        mc.options.forwardKey.setPressed(true); held = true;
        boolean jump = next.getY() > feet.getY() || (p.horizontalCollision && p.isOnGround());
        mc.options.jumpKey.setPressed(jump);
        if (Math.hypot(p.getX() - to.x, p.getZ() - to.z) < 0.3 && Math.abs(p.getY() - next.getY()) < 0.8) path.remove(0);
    }
}
