package com.safeanchor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;

import java.util.List;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Bảng màu tùy chỉnh: 3 thanh R/G/B. */
public class ColorScreen extends MenuScreen {
    final int[] rgb = new int[3];
    public ColorScreen(String title, Screen parent, IntSupplier get, IntConsumer set) {
        super("Chọn màu: " + title, parent, new java.util.ArrayList<>());
        int cur = get.getAsInt();
        rgb[0] = (cur >> 16) & 255; rgb[1] = (cur >> 8) & 255; rgb[2] = cur & 255;
        String[] n = {"Đỏ (R)", "Xanh lá (G)", "Xanh dương (B)"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            makers.add(Pages.slider(n[i], 0, 255, true, () -> rgb[k], v -> { rgb[k] = (int) v; set.accept((rgb[0] << 16) | (rgb[1] << 8) | rgb[2]); }));
        }
    }
    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        super.render(ctx, mx, my, d);
        ctx.fill(width / 2 - 110, 46, width / 2 + 110, 54, 0xFF000000 | (rgb[0] << 16) | (rgb[1] << 8) | rgb[2]);
    }
}
